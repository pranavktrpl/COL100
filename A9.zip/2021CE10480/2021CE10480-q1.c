#include<stdio.h>

int main(){
    int a = 200;
    int b = 100;

    if(b!=0){
        printf("%d",(a*b));
    }else{
        printf("%d",0);
    }
    
    return 0;
}