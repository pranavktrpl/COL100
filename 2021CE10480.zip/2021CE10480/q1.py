a = float(input())
b = float(input())

#sum
print(a+b)

#difference
print(a-b)

#product
print(a*b)

#division
print( ( int( (a/b)*100 ) )/100 )

#mod/remainder
print(a%b)