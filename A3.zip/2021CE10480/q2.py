a = float(input())
b = float(input())
p = int(input())

if p==1:
    print('%.2f' %(a+b))
elif p==2:
    print('%.2f' %(a-b))
elif p==3:
    print('%.2f' %(a*b))
elif p==4:
    print('%.2f' %(a/b))
elif p==5:
    print('%.2f' %(a%b))